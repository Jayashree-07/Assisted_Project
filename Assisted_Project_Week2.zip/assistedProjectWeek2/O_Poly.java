package assistedProjectWeek2;

public class O_Poly {
	public int O_Poly(int x, int y) 
    { 
        return (x + y); 
    } 
    public int O_Poly(int x, int y, int z) 
    { 
        return (x + y + z); 
    } 
    public double O_Poly(double x, double y) 
    { 
        return (x + y); 
    } 

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		O_Poly s = new O_Poly(); 
        System.out.println(s.O_Poly(1.265654, 20.256468)); 
        System.out.println(s.O_Poly(10, 20, 30)); 
        System.out.println(s.O_Poly(104, 205)); 

	}

}

