package assisstedProject;

public class constructorDefault {
		int id;
		String name;

	void display() {
		System.out.println(id+" "+name);
		}
	

		public static void main(String[] args) {

		constructorDefault emp1=new constructorDefault();
		constructorDefault emp2=new constructorDefault();

		emp1.display();
		emp2.display();
		}
	}

