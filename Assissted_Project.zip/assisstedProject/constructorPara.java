package assisstedProject;

public class constructorPara {
	int id;
	String name;

	constructorPara(int i,String n)
	{
	id=i;
	name=n;
	}

	void display() {
	System.out.println(id+" "+name);
	}
public static void main(String[] args) {

	constructorPara std1=new constructorPara(2,"Alex");
	constructorPara std2=new constructorPara(10,"Annie");
	std1.display();
	std2.display();
		}
}
