package assisstedProject;


public class Inner_Class {
 private String msg="Welcome to Java"; 
	 
	 class Inner{  
	  void hello()
{System.out.println(msg+", Let us start learning Inner Classes");}  
	 }  

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Inner_Class obj=new Inner_Class();
		Inner_Class.Inner in=obj.new Inner();  
		in.hello();  

	}

}