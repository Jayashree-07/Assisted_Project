package assisstedProject;

public class method {

public int mul(int a,int b) {
	int z=a*b;
	return z;
}

public static void main(String[] args) {

	method b=new method();
	int ans= b.mul(10,3);
	System.out.println("Multipilcation is :"+ans);
}
}